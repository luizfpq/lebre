
=== COLLEGIATE ===


Keith Bates / K-Type © 2005, 2007 (version 3.01)
www.k-type.com    -    info@k-type.com

Collegiate is a full font based on the lettering around the mosaic tile badge at the Liverpool Collegiate School.

A vector image of the mosaic badge is included at keystroke ±
A vector Liver Bird is included at keystroke §

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------